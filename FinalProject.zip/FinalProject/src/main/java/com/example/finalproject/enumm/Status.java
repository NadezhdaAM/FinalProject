package com.example.finalproject.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен, Отменен
}
